#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJETO_DIR="$SCRIPT_DIR/projeto"
OUTPUT_DIR="$SCRIPT_DIR/apks"
CONFIGURAR="$SCRIPT_DIR/configurar_projeto.py"

if [ -f "$SCRIPT_DIR/.ambiente" ]; then
    source "$SCRIPT_DIR/.ambiente"
fi

export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

TIPO="${1:-debug}"

echo "=== Buildando APK ==="
echo "Tipo: $TIPO"
echo "Projeto: $PROJETO_DIR"

mkdir -p "$OUTPUT_DIR"

if [ ! -d "$PROJETO_DIR" ]; then
    echo "ERRO: Pasta projeto/ nao encontrada"
    exit 1
fi

# ── Auto-fix: sempre rodar configuracao antes do build ──
echo ""
echo "=== Verificando e corrigindo configuracao ==="
python3 "$CONFIGURAR" projeto "$PROJETO_DIR"
echo ""

# ── Auto-fix: detectar e corrigir problemas no gradle.properties ──
PROPS="$PROJETO_DIR/gradle.properties"
if [ -f "$PROPS" ]; then
    FIXED=0

    # Remover linhas duplicadas de jvmargs (manter so a ultima)
    JVMARGS_COUNT=$(grep -c "^org.gradle.jvmargs=" "$PROPS" || true)
    if [ "$JVMARGS_COUNT" -gt 1 ]; then
        # Manter apenas a ultima ocorrencia
        TMPFILE=$(mktemp)
        awk '!seen[$0]++ { if ($0 ~ /^org\.gradle\.jvmargs=/) { if (prev_jvmargs) print prev_jvmargs; prev_jvmargs=$0; next } else { if (prev_jvmargs) { print prev_jvmargs; prev_jvmargs="" } print } } END { if (prev_jvmargs) print prev_jvmargs }' "$PROPS" > "$TMPFILE"
        mv "$TMPFILE" "$PROPS"
        echo "  + Removidas linhas duplicadas de jvmargs"
        FIXED=1
    fi

    # Verificar se Xmx e razoavel (max 2048m)
    JVMARGS=$(grep "^org.gradle.jvmargs=" "$PROPS" | tail -1)
    if echo "$JVMARGS" | grep -q "Xmx[0-9]*[gG]"; then
        GB=$(echo "$JVMARGS" | sed 's/.*Xmx\([0-9]*\)[gG].*/\1/')
        if [ "$GB" -gt 2 ] 2>/dev/null; then
            NEW_JVMARGS=$(echo "$JVMARGS" | sed 's/Xmx[0-9]*[gG]/Xmx2048m/')
            sed -i "s|^org.gradle.jvmargs=.*|${NEW_JVMARGS}|" "$PROPS"
            echo "  + JVM args limitado a 2048m"
            FIXED=1
        fi
    fi

    # Garantir propriedades essenciais
    for PROP in "org.gradle.caching=true" "org.gradle.parallel=true" "org.gradle.daemon=true" "kotlin.incremental=true"; do
        KEY=$(echo "$PROP" | cut -d= -f1)
        if ! grep -q "^${KEY}=" "$PROPS"; then
            echo "$PROP" >> "$PROPS"
            echo "  + Adicionado: $PROP"
            FIXED=1
        fi
    done

    # Garantir que suppressUnsupportedCompileSdk contem compileSdk atual
    COMPILE_SDK=$(grep -oP 'compileSdk\s*=?\s*\K\d+' "$PROJETO_DIR/app/build.gradle.kts" 2>/dev/null || grep -oP 'compileSdk\s*=?\s*\K\d+' "$PROJETO_DIR/app/build.gradle" 2>/dev/null || echo "")
    if [ -n "$COMPILE_SDK" ]; then
        if ! grep -q "android.suppressUnsupportedCompileSdk=.*${COMPILE_SDK}" "$PROPS"; then
            OLD=$(grep "android.suppressUnsupportedCompileSdk=" "$PROPS" | head -1 | cut -d= -f2)
            if [ -n "$OLD" ]; then
                if ! echo "$OLD" | grep -q "$COMPILE_SDK"; then
                    sed -i "s|^android.suppressUnsupportedCompileSdk=.*|android.suppressUnsupportedCompileSdk=${OLD},${COMPILE_SDK},${COMPILE_SDK}.0|" "$PROPS"
                    echo "  + suppressUnsupportedCompileSdk atualizado com SDK $COMPILE_SDK"
                    FIXED=1
                fi
            else
                echo "android.suppressUnsupportedCompileSdk=35,${COMPILE_SDK},${COMPILE_SDK}.0" >> "$PROPS"
                echo "  + suppressUnsupportedCompileSdk adicionado"
                FIXED=1
            fi
        fi
    fi

    # Garantir aapt2 override se existir
    if [ -f "/usr/local/bin/aapt2" ]; then
        if ! grep -q "android.aapt2FromMavenOverride" "$PROPS"; then
            echo "android.aapt2FromMavenOverride=/usr/local/bin/aapt2" >> "$PROPS"
            echo "  + aapt2 override adicionado"
            FIXED=1
        fi
    fi

    if [ "$FIXED" -eq 0 ]; then
        echo "  ✔ gradle.properties ok"
    fi
fi

# ── Auto-fix: verificar gradlew executavel ──
GRADLEW="$PROJETO_DIR/gradlew"
if [ -f "$GRADLEW" ]; then
    if [ ! -x "$GRADLEW" ]; then
        chmod +x "$GRADLEW"
        echo "  + gradlew agora e executavel"
    fi
fi

# ── Auto-fix: verificar compatibilidade AGP/Gradle ──
WRAPPER_PROPS="$PROJETO_DIR/gradle/wrapper/gradle-wrapper.properties"
if [ -f "$WRAPPER_PROPS" ]; then
    GRADLE_VER=$(grep -oP 'gradle-\K[0-9.]+' "$WRAPPER_PROPS" | head -1)
    TOML="$PROJETO_DIR/gradle/libs.versions.toml"
    if [ -f "$TOML" ]; then
        AGP_VER=$(grep -oP '^agp\s*=\s*"\K[^"]+' "$TOML" | head -1)
    else
        ROOT_GRADLE="$PROJETO_DIR/build.gradle.kts"
        [ ! -f "$ROOT_GRADLE" ] && ROOT_GRADLE="$PROJETO_DIR/build.gradle"
        AGP_VER=$(grep -oP 'com\.android\.tools\.build:gradle:\K[^\s"'"'"']+' "$ROOT_GRADLE" 2>/dev/null | head -1)
    fi

    if [ -n "$GRADLE_VER" ] && [ -n "$AGP_VER" ]; then
        AGP_MAJOR=$(echo "$AGP_VER" | cut -d. -f1,2)
        # Mapeamento minimo Gradle por AGP
        case "$AGP_MAJOR" in
            8.13) MIN_GRADLE="8.13" ;;
            8.12) MIN_GRADLE="8.13" ;;
            8.11) MIN_GRADLE="8.11.1" ;;
            8.10) MIN_GRADLE="8.11.1" ;;
            8.9)  MIN_GRADLE="8.11.1" ;;
            8.8)  MIN_GRADLE="8.10.2" ;;
            8.7)  MIN_GRADLE="8.9" ;;
            8.6)  MIN_GRADLE="8.7" ;;
            8.5)  MIN_GRADLE="8.7" ;;
            8.4)  MIN_GRADLE="8.6" ;;
            8.3)  MIN_GRADLE="8.4" ;;
            8.2)  MIN_GRADLE="8.2" ;;
            8.1)  MIN_GRADLE="8.0" ;;
            8.0)  MIN_GRADLE="8.0" ;;
            7.4)  MIN_GRADLE="7.5" ;;
            *)    MIN_GRADLE="" ;;
        esac

        if [ -n "$MIN_GRADLE" ]; then
            # Comparacao simples de versao
            GRADLE_NUM=$(echo "$GRADLE_VER" | tr -d '.')
            MIN_NUM=$(echo "$MIN_GRADLE" | tr -d '.')
            if [ "$GRADLE_NUM" -lt "$MIN_NUM" ] 2>/dev/null; then
                echo "  ! AGP $AGP_VER requer Gradle >= $MIN_GRADLE (atual: $GRADLE_VER)"
                sed -i "s|gradle-${GRADLE_VER}-bin.zip|gradle-${MIN_GRADLE}-bin.zip|" "$WRAPPER_PROPS"
                echo "  + Gradle wrapper atualizado: $GRADLE_VER -> $MIN_GRADLE"
            fi
        fi
    fi
fi

cd "$PROJETO_DIR"

case "$TIPO" in
    debug)
        echo ""
        echo "[1/2] Buildando debug APK..."
        bash gradlew assembleDebug -x stripDebugDebugSymbols -x extractDebugNativeSymbolTables 2>&1
        APK=$(find app/build/outputs/apk/debug -name "*.apk" 2>/dev/null | head -1)
        if [ -n "$APK" ]; then
            mv "$APK" "$OUTPUT_DIR/app-debug.apk"
            echo ""
            echo "=== Debug APK pronto ==="
            echo "Salvo em: $OUTPUT_DIR/app-debug.apk"
        else
            echo "ERRO: APK nao gerado"
            exit 1
        fi
        ;;
    release)
        echo ""
        echo "[1/2] Buildando release APK..."
        bash gradlew assembleRelease -x stripReleaseDebugSymbols -x extractReleaseNativeSymbolTables 2>&1
        APK=$(find app/build/outputs/apk/release -name "*.apk" ! -name "*.idsig" 2>/dev/null | head -1)
        if [ -n "$APK" ]; then
            cp "$APK" "$OUTPUT_DIR/app-release.apk"
        else
            echo "ERRO: APK release nao gerado"
            exit 1
        fi

        echo ""
        echo "[2/2] Verificando assinatura..."
        for VER in 36.0.0 35.0.0 34.0.0; do
            BUILD_TOOLS="$ANDROID_HOME/build-tools/$VER"
            [ -d "$BUILD_TOOLS" ] && break
        done

        "$BUILD_TOOLS/apksigner" verify "$OUTPUT_DIR/app-release.apk" && echo "  Assinatura OK!"

        echo ""
        echo "=== Release APK pronto ==="
        echo "Salvo em: $OUTPUT_DIR/app-release.apk"
        ;;
    appbundle|bundle|aab)
        echo ""
        echo "[1/2] Buildando App Bundle..."
        bash gradlew bundleRelease -x stripReleaseDebugSymbols -x extractReleaseNativeSymbolTables 2>&1
        AAB=$(find app/build/outputs/bundle/release -name "*.aab" 2>/dev/null | head -1)
        if [ -n "$AAB" ]; then
            mv "$AAB" "$OUTPUT_DIR/app-release.aab"
            echo ""
            echo "=== App Bundle pronto ==="
            echo "Salvo em: $OUTPUT_DIR/app-release.aab"
        else
            echo "ERRO: AAB nao gerado"
            exit 1
        fi
        ;;
    *)
        echo "Uso: $0 [debug|release|appbundle]"
        echo ""
        echo "  debug     - Build debug APK (padrao)"
        echo "  release   - Build release APK assinado com chave do projeto"
        echo "  appbundle - Build App Bundle (.aab)"
        exit 1
        ;;
esac

echo ""
echo "=== Build concluido! ==="
